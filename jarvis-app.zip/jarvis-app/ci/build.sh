#!/usr/bin/env bash
# Monta o APK do Jarvis. Roda dentro da pasta do projeto (onde esta o package.json).
set -uo pipefail
LOG=build.log
: > "$LOG"
exec > >(tee -a "$LOG") 2>&1

SUM="${GITHUB_STEP_SUMMARY:-/dev/null}"
MAN=android/app/src/main/AndroidManifest.xml
RES=android/app/src/main/res
DIR=android/app/src/main/java/com/pessoal/jarvis

summary_fail() {
  {
    echo "## A montagem falhou"
    echo "Copie o texto abaixo e envie para quem esta te ajudando:"
    echo '```'
    grep -n -E "error:|FAILED|What went wrong|ERR!|Could not|Execution failed|not found|No such file" "$LOG" | head -40
    echo '--- final do log ---'
    tail -n 25 "$LOG"
    echo '```'
  } >> "$SUM"
}

step() { echo; echo "==== $1"; }
die() { echo "::error::$1"; summary_fail; exit 1; }

step "Instalando dependencias"
npm install --no-audit --no-fund --legacy-peer-deps || die "npm install falhou"

build_full() {
  step "Criando o projeto Android"
  npx cap add android || return 1
  step "Permissoes, assistente e plugins nativos"
  sed -i '/android.permission.INTERNET/r ci/perms.txt' "$MAN" || return 1
  python3 ci/patch_manifest.py "$MAN" ci/assist.txt || return 1
  mkdir -p "$DIR" && cp ci/java/*.java "$DIR/" || return 1
  sed -i '0,/^dependencies {/s//dependencies {\n    implementation "androidx.biometric:biometric:1.1.0"/' android/app/build.gradle || return 1
  grep -q "androidx.biometric" android/app/build.gradle || return 1
  step "Icone e tela de abertura"
  if [ -d icons ]; then cp -r icons/* "$RES/"; else echo "pasta icons ausente: icone padrao"; fi
  sed -i 's/#FFFFFF/#02060C/I' "$RES/values/ic_launcher_background.xml" || true
  find "$RES" -name 'splash*.png' -delete
  mkdir -p "$RES/drawable"
  if [ -f ci/splash.png ]; then cp ci/splash.png "$RES/drawable/splash.png"; else cp ci/splash_solid.xml "$RES/drawable/splash.xml"; fi
  step "Sincronizando"
  npx cap sync android || return 1
  step "Compilando (versao completa)"
  (cd android && ./gradlew assembleDebug --no-daemon --stacktrace)
}

build_lite() {
  step "Plano B: recriando o projeto Android do zero (versao simples)"
  rm -rf android
  npx cap add android || return 1
  sed -i '/android.permission.INTERNET/r ci/perms_lite.txt' "$MAN" || return 1
  mkdir -p "$DIR" && cp ci/java/SpeechPlugin.java "$DIR/SpeechPlugin.java" && cp ci/java/MainActivityLite.java.txt "$DIR/MainActivity.java" || return 1
  npx cap sync android || return 1
  step "Compilando (versao simples)"
  (cd android && ./gradlew assembleDebug --no-daemon --stacktrace)
}

if build_full; then
  echo "Versao completa compilada."
else
  echo "::warning::A versao completa nao compilou. Montando a versao simples (sem digital, SMS, agenda, alarmes, lanterna e segundo plano)."
  { echo "## Aviso"; echo "A versao completa nao compilou; foi montada a versao simples."; echo '```'; grep -n -E "error:|FAILED|What went wrong|Execution failed" "$LOG" | head -30; echo '```'; } >> "$SUM"
  if build_lite; then
    echo "LITE=1" >> "${GITHUB_ENV:-/dev/null}"
  else
    die "A versao simples tambem nao compilou"
  fi
fi

APK=android/app/build/outputs/apk/debug/app-debug.apk
[ -f "$APK" ] || die "O APK nao foi gerado"
ls -la "$APK"
{ echo "## APK pronto"; echo "Baixe em Releases (ou em Artifacts, no fim desta pagina)."; } >> "$SUM"
