import sys
man, assist = sys.argv[1], sys.argv[2]
s = open(man, encoding="utf-8").read()
block = open(assist, encoding="utf-8").read()
i = s.index("</activity>")
s = s[:i] + block + s[i:]
k = s.index("</application>")
s = s[:k] + '    <service android:name=".JarvisService" android:exported="false" android:foregroundServiceType="microphone" />\n    ' + s[k:]
open(man, "w", encoding="utf-8").write(s)
print("manifest ok")
