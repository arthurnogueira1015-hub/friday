package com.pessoal.jarvis;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import java.util.ArrayList;

@CapacitorPlugin(
    name = "SpeechRecognition",
    permissions = {
        @Permission(strings = { Manifest.permission.RECORD_AUDIO }, alias = "speechRecognition")
    }
)
public class SpeechPlugin extends Plugin {
    private SpeechRecognizer sr;

    private void emitMatches(ArrayList<String> r) {
        if (r == null || r.isEmpty()) return;
        JSArray arr = new JSArray();
        for (String s : r) arr.put(s);
        JSObject o = new JSObject();
        o.put("matches", arr);
        notifyListeners("partialResults", o);
    }

    private void emitState(String st) {
        JSObject o = new JSObject();
        o.put("status", st);
        notifyListeners("listeningState", o);
    }

    @PluginMethod
    public void start(final PluginCall call) {
        if (!SpeechRecognizer.isRecognitionAvailable(getContext())) {
            call.reject("unavailable");
            return;
        }
        final String lang = call.getString("language", "pt-BR");
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (sr != null) { sr.destroy(); sr = null; }
                    sr = SpeechRecognizer.createSpeechRecognizer(getContext());
                    sr.setRecognitionListener(new RecognitionListener() {
                        @Override public void onReadyForSpeech(Bundle params) { emitState("started"); }
                        @Override public void onBeginningOfSpeech() {}
                        @Override public void onRmsChanged(float rmsdB) {}
                        @Override public void onBufferReceived(byte[] buffer) {}
                        @Override public void onEndOfSpeech() {}
                        @Override public void onError(int error) { emitState("stopped"); }
                        @Override public void onResults(Bundle results) {
                            emitMatches(results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION));
                            emitState("stopped");
                        }
                        @Override public void onPartialResults(Bundle partialResults) {
                            emitMatches(partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION));
                        }
                        @Override public void onEvent(int eventType, Bundle params) {}
                    });
                    Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
                    i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
                    i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
                    sr.startListening(i);
                    call.resolve();
                } catch (Exception e) {
                    call.reject("failed");
                }
            }
        });
    }

    @PluginMethod
    public void stop(final PluginCall call) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try { if (sr != null) sr.stopListening(); } catch (Exception e) {}
                call.resolve();
            }
        });
    }

    @PluginMethod
    public void cancel(final PluginCall call) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try { if (sr != null) sr.cancel(); } catch (Exception e) {}
                emitState("stopped");
                call.resolve();
            }
        });
    }

    @Override
    protected void handleOnDestroy() {
        if (sr != null) {
            try { sr.destroy(); } catch (Exception e) {}
            sr = null;
        }
        super.handleOnDestroy();
    }
}
