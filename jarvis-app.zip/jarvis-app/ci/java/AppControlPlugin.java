package com.pessoal.jarvis;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import android.view.KeyEvent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.ContactsContract;
import android.telephony.SmsManager;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import java.util.ArrayList;
import java.util.concurrent.Executor;

@CapacitorPlugin(
    name = "AppControl",
    permissions = {
        @Permission(strings = { Manifest.permission.READ_CONTACTS }, alias = "contacts"),
        @Permission(strings = { Manifest.permission.SEND_SMS }, alias = "sms"),
        @Permission(strings = { Manifest.permission.READ_CALENDAR }, alias = "calendar"),
        @Permission(strings = { Manifest.permission.CALL_PHONE }, alias = "call")
    }
)
public class AppControlPlugin extends Plugin {

    @PluginMethod
    public void launch(PluginCall call) {
        String pkg = call.getString("package");
        Intent i = getContext().getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) { call.reject("not installed"); return; }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
        call.resolve();
    }

    @PluginMethod
    public void action(PluginCall call) {
        try {
            Intent i = new Intent(call.getString("action"));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject("failed"); }
    }

    @PluginMethod
    public void open(PluginCall call) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(call.getString("url")));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject("failed"); }
    }

    @PluginMethod
    public void getContacts(PluginCall call) {
        if (getPermissionState("contacts") != PermissionState.GRANTED) {
            requestPermissionForAlias("contacts", call, "contactsCb");
            return;
        }
        doContacts(call);
    }

    @PermissionCallback
    private void contactsCb(PluginCall call) {
        if (getPermissionState("contacts") == PermissionState.GRANTED) doContacts(call);
        else call.reject("denied");
    }

    private void doContacts(PluginCall call) {
        JSArray arr = new JSArray();
        Cursor c = getContext().getContentResolver().query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            new String[] {
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            },
            null, null,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC");
        if (c != null) {
            while (c.moveToNext() && arr.length() < 5000) {
                JSObject o = new JSObject();
                o.put("n", c.getString(0));
                o.put("t", c.getString(1));
                arr.put(o);
            }
            c.close();
        }
        JSObject r = new JSObject();
        r.put("contacts", arr);
        call.resolve(r);
    }

    @PluginMethod
    public void sendSms(PluginCall call) {
        if (getPermissionState("sms") != PermissionState.GRANTED) {
            requestPermissionForAlias("sms", call, "smsCb");
            return;
        }
        doSms(call);
    }

    @PermissionCallback
    private void smsCb(PluginCall call) {
        if (getPermissionState("sms") == PermissionState.GRANTED) doSms(call);
        else call.reject("denied");
    }

    private void doSms(PluginCall call) {
        try {
            SmsManager sm = Build.VERSION.SDK_INT >= 31
                ? getContext().getSystemService(SmsManager.class)
                : SmsManager.getDefault();
            ArrayList<String> parts = sm.divideMessage(call.getString("text"));
            sm.sendMultipartTextMessage(call.getString("to"), null, parts, null, null);
            call.resolve();
        } catch (Exception e) { call.reject("failed"); }
    }

    @PluginMethod
    public void background(PluginCall call) {
        boolean on = Boolean.TRUE.equals(call.getBoolean("on", false));
        try {
            Intent i = new Intent(getContext(), JarvisService.class);
            if (on) {
                if (Build.VERSION.SDK_INT >= 26) getContext().startForegroundService(i);
                else getContext().startService(i);
            } else {
                getContext().stopService(i);
            }
            call.resolve();
        } catch (Exception e) { call.reject("failed"); }
    }

    @PluginMethod
    public void authenticate(final PluginCall call) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Executor ex = ContextCompat.getMainExecutor(getContext());
                    BiometricPrompt bp = new BiometricPrompt((FragmentActivity) getActivity(), ex,
                        new BiometricPrompt.AuthenticationCallback() {
                            @Override
                            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                                call.resolve();
                            }
                            @Override
                            public void onAuthenticationError(int errorCode, CharSequence errString) {
                                call.reject("denied");
                            }
                        });
                    BiometricPrompt.PromptInfo.Builder b = new BiometricPrompt.PromptInfo.Builder()
                        .setTitle("Jarvis")
                        .setSubtitle(call.getString("reason", "Confirme que e voce"));
                    if (Build.VERSION.SDK_INT >= 30) {
                        b.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG
                            | BiometricManager.Authenticators.DEVICE_CREDENTIAL);
                    } else {
                        b.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
                         .setNegativeButtonText("Cancelar");
                    }
                    bp.authenticate(b.build());
                } catch (Exception e) { call.reject("failed"); }
            }
        });
    }

    @PluginMethod
    public void alarm(PluginCall call) {
        try {
            int hour = call.getInt("hour", 7);
            int minute = call.getInt("minute", 0);
            Intent i = new Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, call.getString("message", "Jarvis"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject("failed"); }
    }

    @PluginMethod
    public void torch(PluginCall call) {
        try {
            CameraManager cm = (CameraManager) getContext().getSystemService(Context.CAMERA_SERVICE);
            boolean on = Boolean.TRUE.equals(call.getBoolean("on", true));
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics cc = cm.getCameraCharacteristics(id);
                Boolean flash = cc.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
                if (flash != null && flash && facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    cm.setTorchMode(id, on);
                    call.resolve();
                    return;
                }
            }
            call.reject("no flash");
        } catch (Exception e) { call.reject("failed"); }
    }

    @PluginMethod
    public void volume(PluginCall call) {
        try {
            AudioManager am = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
            String act = call.getString("action", "set");
            int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            if ("up".equals(act)) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
            } else if ("down".equals(act)) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
            } else if ("mute".equals(act)) {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI);
            } else {
                int pct = call.getInt("level", 50);
                am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(max * pct / 100f), AudioManager.FLAG_SHOW_UI);
            }
            call.resolve();
        } catch (Exception e) { call.reject("failed"); }
    }

    @PluginMethod
    public void media(PluginCall call) {
        try {
            String k = call.getString("key", "playpause");
            int code = KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE;
            if ("next".equals(k)) code = KeyEvent.KEYCODE_MEDIA_NEXT;
            else if ("prev".equals(k)) code = KeyEvent.KEYCODE_MEDIA_PREVIOUS;
            else if ("stop".equals(k)) code = KeyEvent.KEYCODE_MEDIA_STOP;
            else if ("play".equals(k)) code = KeyEvent.KEYCODE_MEDIA_PLAY;
            else if ("pause".equals(k)) code = KeyEvent.KEYCODE_MEDIA_PAUSE;
            AudioManager am = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
            am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, code));
            am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, code));
            call.resolve();
        } catch (Exception e) { call.reject("failed"); }
    }

    @PluginMethod
    public void dial(PluginCall call) {
        if (getPermissionState("call") != PermissionState.GRANTED) {
            requestPermissionForAlias("call", call, "dialCb");
            return;
        }
        doDial(call);
    }

    @PermissionCallback
    private void dialCb(PluginCall call) {
        if (getPermissionState("call") == PermissionState.GRANTED) doDial(call);
        else call.reject("denied");
    }

    private void doDial(PluginCall call) {
        try {
            Intent i = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(call.getString("number"))));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject("failed"); }
    }

    @PluginMethod
    public void calendar(PluginCall call) {
        if (getPermissionState("calendar") != PermissionState.GRANTED) {
            if (Boolean.TRUE.equals(call.getBoolean("silent", false))) { call.reject("denied"); return; }
            requestPermissionForAlias("calendar", call, "calendarCb");
            return;
        }
        doCalendar(call);
    }

    @PermissionCallback
    private void calendarCb(PluginCall call) {
        if (getPermissionState("calendar") == PermissionState.GRANTED) doCalendar(call);
        else call.reject("denied");
    }

    private void doCalendar(PluginCall call) {
        try {
            int days = call.getInt("days", 1);
            java.util.Calendar c = java.util.Calendar.getInstance();
            c.set(java.util.Calendar.HOUR_OF_DAY, 0);
            c.set(java.util.Calendar.MINUTE, 0);
            c.set(java.util.Calendar.SECOND, 0);
            c.set(java.util.Calendar.MILLISECOND, 0);
            long start = c.getTimeInMillis();
            long end = start + days * 24L * 3600L * 1000L;
            Cursor cur = CalendarContract.Instances.query(
                getContext().getContentResolver(),
                new String[] {
                    CalendarContract.Instances.TITLE,
                    CalendarContract.Instances.BEGIN,
                    CalendarContract.Instances.END,
                    CalendarContract.Instances.EVENT_LOCATION,
                    CalendarContract.Instances.ALL_DAY
                },
                start, end);
            JSArray arr = new JSArray();
            if (cur != null) {
                while (cur.moveToNext() && arr.length() < 60) {
                    JSObject o = new JSObject();
                    o.put("title", cur.getString(0));
                    o.put("begin", cur.getLong(1));
                    o.put("end", cur.getLong(2));
                    o.put("where", cur.getString(3));
                    o.put("allDay", cur.getInt(4) == 1);
                    arr.put(o);
                }
                cur.close();
            }
            JSObject r = new JSObject();
            r.put("events", arr);
            call.resolve(r);
        } catch (Exception e) { call.reject("failed"); }
    }

    @PluginMethod
    public void addEvent(PluginCall call) {
        try {
            long begin = call.getData().optLong("begin", System.currentTimeMillis() + 3600000L);
            Intent i = new Intent(Intent.ACTION_INSERT)
                .setData(CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.Events.TITLE, call.getString("title", "Compromisso"))
                .putExtra(CalendarContract.Events.EVENT_LOCATION, call.getString("where", ""))
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, begin + 3600000L);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject("failed"); }
    }
}
